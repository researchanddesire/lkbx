# Revised Lockbox button STEP payloads

This archive contains the actual revised `back-button.step` and
`enter-button.step` models. They retain their original assembly coordinates.

Before merging this review revision, upload both STEP payloads to Git LFS and
update the canonical `hardware/cad/back-button.step` and
`hardware/cad/enter-button.step` paths. Those canonical files still contain the
previous revision in this review commit. Verify the payloads against
`SHA256SUMS`.

Changes: body length 15.5 → 19.5 mm; original sockets translated rearward 4 mm
with 5.2 mm depth preserved; separate 0.6 mm icon inlays flush at Z = 0; shoulder
chamfer 60° from vertical, with a 1.000 mm radial run and 0.57735 mm axial rise
at Z = 10.800–11.37735 mm.

CAD and mesh validation passed. Printing and physical fit have not been tested.
